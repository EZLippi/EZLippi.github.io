/*
 * Created on Jan 23, 2006
 *
 * @author bbehling
 *
 */
package com.remedy.arsys.sso;

import com.remedy.arsys.session.Authenticator;
import com.remedy.arsys.session.UserCredentials;
import java.io.*;
import javax.servlet.http.*;
import java.util.*;
//import java.net.*;
import com.remedy.arsys.log.Log;

/**
 * @author bbehling
 *
 * THE SAMPLE CODE AND OTHER INFORMATION PROVIDED IN THIS WHITE PAPER ARE EACH PROVIDED WITH NO WARRANTIES
 * OR SUPPORT WHATSOEVER, AND BMC, ITS AFFILIATES AND LICENSORS DISCLAIM ALL WARRANTIES, INCLUDING,
 * WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 * AND NON-INFRINGEMENT, AND ALL RESPONSIBILITY FOR SUPPORT AND/OR MAINTENANCE.
 * BMC DOES NOT WARRANT THAT THE OPERATION OF THE SAMPLE CODE WILL BE UNINTERRUPTED OR ERROR FREE.
 *
 */
public class SSOAuthenticator implements Authenticator
{
	public static final String VERSION = "2.06 (Mid-Tier 7.0.x build)";
	public static final String AUTH_STRING = "Qk1DIFJlbWVkeSBBUlN5c3RlbQ==";
	public static final String PASS_STRING = "c3NvcGFzc3dvcmQ=";
	Properties propTable = new Properties();
	protected static Log mtLog = Log.get(Log.SESSION);
	String usermethod, usercase, removedomain, headername, attname, authmethod, authcustom, debuglogging;
	boolean debug = false;

	public void init(Map cfg)
    {
		mtLog.fine("SSO: Initialization: Version "+VERSION);
		int cfgsize = cfg.size();
		if(cfgsize < 0)
		{
			mtLog.fine("SSO: ERROR: No property values were loaded. ");
			mtLog.fine("  Check the following settings:");
			mtLog.fine("  1) sso.properties file is located in the Mid-Tier /classes directory");
			mtLog.fine("  2) arsystem.authenticator.config.file=sso.properties is set in your config.properties file");
		}
		else
		{
			mtLog.fine("SSO: Property values were loaded. ");
			usermethod = (String)cfg.get("arsystem.sso.username.method");
			usercase = (String)cfg.get("arsystem.sso.username.case");
			removedomain = (String)cfg.get("arsystem.sso.username.remoteuser_remove_domain");
			headername = (String)cfg.get("arsystem.sso.username.headername");
			attname = (String)cfg.get("arsystem.sso.username.attributename");
			authmethod = (String)cfg.get("arsystem.sso.authstring.method");
			authcustom = (String)cfg.get("arsystem.sso.authstring.custom");
			debuglogging = (String)cfg.get("arsystem.sso.logging.debug");

			if(debuglogging != null && debuglogging.equalsIgnoreCase("T"))
			{
				debug = true;
			}
		}
    }

    public UserCredentials getAuthenticatedCredentials(HttpServletRequest request, HttpServletResponse response) throws IOException
    {
    	String username;
    	// Use getRemoteuser call to get username
    	if (usermethod != null && usermethod.equalsIgnoreCase("remoteuser"))
    	{
    		String remoteUser = request.getRemoteUser();
    		if(remoteUser != null && !remoteUser.equals(""))
    		{
    			if(debug){
    				mtLog.fine("SSO: Remote User Name (including domain): "+ remoteUser);
    			}
    			// Use removedomain to parse domain name from getRemoteUser call
        		if(removedomain != null && removedomain.equalsIgnoreCase("T"))
        		{
        			int startpoint = remoteUser.indexOf("\\") + 1;
        			int endpoint = remoteUser.length();
        			String rUserNoDomain = remoteUser.substring(startpoint, endpoint);
        			//remoteUser = remoteUser.substring(startpoint, endpoint);
        			if(debug){
        				mtLog.fine("SSO: Remote User Name (no domain): "+ rUserNoDomain);
        			}
        			username = rUserNoDomain;
        			return new UserCredentials(getUserName(username), PASS_STRING, getAuthString(remoteUser));
        		}
        		else
        		{
        			username = remoteUser;
        			return new UserCredentials(getUserName(username), PASS_STRING, getAuthString(remoteUser));
        		}
    		}
    		else
    		{
    			mtLog.fine("SSO ERROR: RemoteUser name is null or empty. Using default login page");
    			return new UserCredentials(null, null, null);
    		}
    	}
    	// Use getHeader call to get username
    	else if (usermethod != null && usermethod.equalsIgnoreCase("header"))
    	{
    		String header = null;
    		if(headername != null)
    		{
    			header = request.getHeader(headername);
    		}
    		else
    		{
    			mtLog.fine("SSO: ERROR: Header Name is null. Using default login page");
    			return new UserCredentials(null, null, null);
    		}
    		if(header != null && !header.equals(""))
    		{
    			if(debug){
    				mtLog.fine("SSO: Request Header value (username): "+ header);
    			}
    			username = header;
    			return new UserCredentials(getUserName(username), PASS_STRING, getAuthString(null));
    		}
    		else
    		{
    			mtLog.fine("SSO ERROR: Header is null or empty. Using default login page");
    			return new UserCredentials(null, null, null);
    		}
    	}
    	// Use a session attribute to get the username
    	else if(usermethod != null && usermethod.equalsIgnoreCase("attribute"))
    	{
    		HttpSession session = request.getSession(false);
            if(session != null){
            	if(attname != null || !attname.equals(""))
            	{
            		String attribute = (String)session.getAttribute(attname);
            		if(debug){
            			mtLog.fine("SSO: Attribute value (username): "+ attribute);
            		}
            		username = attribute;
            		return new UserCredentials(getUserName(username), PASS_STRING, getAuthString(null));
            	}
            	else
            	{
            		mtLog.fine("SSO ERROR: Session Attribute name is null or empty. Using default login page");
        			return new UserCredentials(null, null, null);
            	}
            }
            else
            {
            	mtLog.fine("SSO ERROR: Session attibute is null. Using default login page");
            	return new UserCredentials(null, null, null);
            }
    	}
    	else
    	{
    		// No setting (in sso.properties) was provided to get the username
    		mtLog.fine("SSO ERROR: No valid method defined in sso.properties to get username. Using default login page");
    		return new UserCredentials(null, null, null);
    	}

    	// Dev override
    	//username = "Demo";
    	//password = "remedy";
    	//authString = "";
    	//return new UserCredentials(username, password, AUTH_STRING);

    	// Default return to login.jsp
    	//return new UserCredentials(username, pass, auth);
    }

    public String getAuthString(String rUser)
    {
    	String resAuth = null;
		if(authmethod != null && authmethod.equalsIgnoreCase("rudomain"))
		{
			if(rUser != null)
			{
    			int end = rUser.indexOf("\\");
    			String rudomain = rUser.substring(0, end);
    			resAuth = rudomain;
			}
			else
			{
				mtLog.fine("SSO ERROR: An Authentication string was not defined, because remoteUser is null.");
				resAuth = null;
			}
		}
		else if (authmethod != null && authmethod.equalsIgnoreCase("default"))
		{
			resAuth = AUTH_STRING;
		}
		else if (authmethod != null && authmethod.equalsIgnoreCase("custom"))
		{
			resAuth = authcustom;
		}
		else
		{
			mtLog.fine("SSO ERROR: An authentication string method was not defined, returning null.");
			resAuth = null;
		}
		if(debug){
			mtLog.fine("SSO: Using AuthString: "+resAuth);
		}
		return resAuth;

    }

    public String getUserName(String uname)
    {
    	if(usercase != null)
    	{
    		if(usercase.equalsIgnoreCase("lower"))
    		{
        		if(debug){
        			mtLog.fine("SSO: Setting username to lower case...");
        		}
    			uname = uname.toLowerCase();
    		}
    		else if(usercase.equalsIgnoreCase("upper"))
    		{
    			if(debug){
        			mtLog.fine("SSO: Setting username to upper case...");
        		}
    			uname = uname.toUpperCase();
    		}
    		else
    		{
    			if(debug){
        			mtLog.fine("SSO: Using username default case.");
        		}
    			// don't do anything, leave it as is...
    		}
    	}
    	else
    	{
    		if(debug){
    			mtLog.fine("SSO: arsystem.sso.username.case is null. Using default username case.");
    		}
    		return uname;
    	}
    	if(debug){
    		mtLog.fine("SSO: Authenticating with username: "+uname);
    	}
    	return uname;
    }

    public void destroy()
    {
    }
}
