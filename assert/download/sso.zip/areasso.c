
/*  File: areasso.c  */

/**
 * @author bbehling
 *
 * THE SAMPLE CODE AND OTHER INFORMATION PROVIDED IN THIS WHITE PAPER ARE EACH PROVIDED WITH NO WARRANTIES
 * OR SUPPORT WHATSOEVER, AND BMC, ITS AFFILIATES AND LICENSORS DISCLAIM ALL WARRANTIES, INCLUDING,
 * WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 * AND NON-INFRINGEMENT, AND ALL RESPONSIBILITY FOR SUPPORT AND/OR MAINTENANCE.
 * BMC DOES NOT WARRANT THAT THE OPERATION OF THE SAMPLE CODE WILL BE UNINTERRUPTED OR ERROR FREE.
 *
 */

#ifdef _WIN32
#include <windows.h>
#endif /* _WIN32 */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "area.h"
#ifdef _WIN32
#define SSO_CONF_FILE "C:\\Program Files\\AR System\\CONF\\areasso.cfg"
#else
#define SSO_CONF_FILE "/usr/ar/conf/areasso.conf"  // <---- NEED TO ADJUST THIS ????
#endif

/* Version String */
#define VERSION "2.09"

/*
* 2.07 - Added support for remote Crystal (BOXI) server requests. 
* 2.08 - Fixed crashing issue caused by (null) password or authstring
* 2.09 - Added additional (null) checks
*/

/* Init for Logging */
AR_PLUGIN_LOG_FUNCTION logFunc = NULL;
ARPluginIdentification id;
void logInfo (char  *info);
void logSevere(char  *info);
void logDebug(char  *info);
long debug_logging;

/* Init for areasso.conf settings */
#define MID_TIER_IP "MID-TIER-IP:"
#define BOXI_IP "BOXI-IP:"
#define AUTH_STRING "AUTH-STRING:"
#define DEBUG_LOGGING "DEBUG-LOGGING:"
#define LICENSE_MASK "LICENSE-MASK:"
#define LICENSE_TYPE "LICENSE-TYPE:"
#define LICENSE_FTS "LICENSE-FTS:"
#define LICENSE_APPS "LICENSE-APPS:"
#define GROUP_MEMBERSHIP "GROUP-MEMBERSHIP:"
#define GROUP_NAMES "GROUP-NAMES:"
#define NOTIFY_MECH "NOTIFY-MECH:"
#define AR_DEFN_FILE_COMMENT '#'
char boxi_ip[16];
long license_mask;
long license_type;
long license_fts;
char license_apps[255];
long group_membership;
char group_names[255];
long notify_mech;
FILE *fp;
char filepath[250];
char *conffile;
int position;
char buffer[AR_MAX_FULL_FILENAME + 31];
char tempBuf[AR_MAX_FULL_FILENAME + 1];
int lengthOfBuffer;
int fcstatus;
int i;
int y;
char empty[16];

/* Init for VerifyCallback */
#define AUTH_STRING_DEFAULT "Qk1DIFJlbWVkeSBBUlN5c3RlbQ=="
#define PASS_STRING "c3NvcGFzc3dvcmQ="
int passed_login;
struct midtier
{
	char value[16]; // max length of an IP address is 16
};
struct authstring
{
	char value[255];
};
struct midtier midtier_list[25];
int midtier_count = 0;
struct authstring authstring_list[25];
int authstring_count = 0;

/*****************************************************************************/
/*                                                                           */
/*       Action Request System External Authentication (AREA) Sample         */
/*                                                                           */
/*****************************************************************************/
/* Description: This is a sample external authentication plug-in.  It is     */
/*    intended for use by AR System customers in implementing a customized      */
/*    authentication plug-in.                                                */
/*                                                                           */
/*    This sample allows the user "Good User" to log in and acquire a        */
/*    floating license if one is available.  The user "Bad User" is not      */
/*    allowed to login.  Any other users are unknown and it is up to the     */
/*    AR System server to log the user in as a guest user.                   */
/*                                                                           */
/*****************************************************************************/

#ifdef _WIN32
BOOL APIENTRY DllMain( HANDLE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
					 )
{
   return TRUE;
}

#endif /* _WIN32 */

/*****************************************************************************/
/*                                                                           */
/*                             ARPluginIdentify                              */
/*                                                                           */
/*****************************************************************************/
/* Description: This function is called by the plug-in service to identify   */
/*    what type of plug-in this implements.                                  */
/*                                                                           */
/*****************************************************************************/

ARPLUGIN_EXPORT int ARPluginIdentify(
ARPluginIdentification *id,     /* OUT; information about the plug-in */
ARStatusList           *status  /* OUT; error message(s)*/
)
{
   id->type = AR_PLUGIN_TYPE_AREA;
   strcpy(id->name, "AREA.SSO");
   id->version = AREA_PLUGIN_VERSION;
   memset(status, 0, sizeof(status));

   return AR_RETURN_OK;
}


/*****************************************************************************/
/*                                                                           */
/*                          ARPluginInitialization                           */
/*                                                                           */
/*****************************************************************************/
/* Description: This function is called by the plug-in service to initilize  */
/*    the plug-in.  This is where the plug-in should initialize any data     */
/*    that will be global and accessed by all instances of the plug-in that  */
/*    are created via ARPluginCreateInstance().                              */
/*                                                                           */
/*****************************************************************************/

ARPLUGIN_EXPORT int ARPluginInitialization(
int argc,             /*  IN; argc from main() */
char **argv,          /*  IN; argv from main() */
ARStatusList *status
)
{
    logInfo ("AREA SSO Plugin Initialization: Version:");
    logInfo (VERSION);

	// Default all the cfg setting, in case they don't exist or are pounded out.
	*boxi_ip=NULL;
	debug_logging=0; // Off
	license_mask=0; // Do not assign licenses
	license_type=0; // None
	license_fts=0; // None
	*license_apps=NULL; // NULL
	group_membership=0; // Off
	*group_names=NULL; //NULL
	notify_mech=0; // None

	// Get the path to the areasso.cfg file from the env variable
	conffile = getenv("ARSSO_CONF_FILE");

	if (conffile==NULL) // No env variable found, use default ARServer install path.
	{
		logInfo("Could not find ARSSO_CONF_FILE env variable. Setting to default path.");
		strcpy (filepath,SSO_CONF_FILE);
	}
	else
	{
		logInfo("Found ARSSO_CONF_FILE env variable");
		strcpy (filepath, conffile);
	}

	logInfo ("Using ARSSO_CONF_FILE path:");
	logInfo (filepath);

   	if ((fp = fopen(filepath,"r"))==NULL) // Could not find or open the areasso.cfg file
    {
		logSevere ("ERROR: Cannot open areasso.cfg file.");
    }
	else
	{
		logInfo ("Found and opened areasso.cfg file.");
	}

	// Get the settings from the conf file
   if (fp != NULL)
   {
      while (fgets(buffer, (AR_MAX_FULL_FILENAME + 30), fp) != NULL)
      {
         if ((buffer[0] == AR_DEFN_FILE_COMMENT) || (buffer[0] == '\n'))
            continue;
         // strip trailing '\n' and whitespace
         position = strlen(buffer) - 1;
         while ((position >= 0) &&
                ((buffer[position] == '\n') || (buffer[position] == '\r') ||
                 (buffer[position] == ' ') || (buffer[position] == '\t')))
            position--;
         if (position < 0)
            continue;            // all whitespace so ignore
         position++;
         lengthOfBuffer = position;
         buffer[position] = '\0';

		 // Get all MID_TIER_IP settings from the areasso.cfg file
         if (strncmp(buffer, MID_TIER_IP, strlen(MID_TIER_IP)) == 0)
         {
            position = strlen(MID_TIER_IP);
            while ((buffer[position] == ' ') || (buffer[position] == '\t'))
               position++;
            if (strlen(&buffer[position]) <=
                (size_t) (AR_MAX_FULL_FILENAME - AR_MAX_FILENAME_SIZE))
               strcpy(tempBuf, &buffer[position]);
            ///else               ** name too long; ignore it...
			logInfo ("Adding MID-TIER-IP:");
			logInfo(tempBuf);

			// Copy this value to the next element of the midtier_list array
			strcpy (midtier_list[midtier_count].value,tempBuf);
			// Increase the midtier_count
			midtier_count = midtier_count+1;
         }

		 // BOXI-IP: BOXI_IP
		 else if (strncmp(buffer, BOXI_IP, strlen(BOXI_IP)) == 0)
         {
         	position = strlen(BOXI_IP);
         	while ((buffer[position] == ' ') || (buffer[position] == '\t'))
         	position++;
         	if (strlen(&buffer[position]) <=
                (size_t) (AR_MAX_FULL_FILENAME - AR_MAX_FILENAME_SIZE))
         		strcpy(tempBuf, &buffer[position]);
         	///else               ** name too long; ignore it...
	     	logInfo("BOXI-IP:");
		 	logInfo(tempBuf);
		 	strcpy(boxi_ip, tempBuf);
         }

		 // Get all AUTH_STRING settings from the areasso.cfg file
         if (strncmp(buffer, AUTH_STRING, strlen(AUTH_STRING)) == 0)
         {
            position = strlen(AUTH_STRING);
            while ((buffer[position] == ' ') || (buffer[position] == '\t'))
               position++;
            if (strlen(&buffer[position]) <=
                (size_t) (AR_MAX_FULL_FILENAME - AR_MAX_FILENAME_SIZE))
               strcpy(tempBuf, &buffer[position]);
            ///else               ** name too long; ignore it...
			logInfo ("Adding AUTH-STRING:");
			logInfo(tempBuf);

			// Copy this value to the next element of the midtier_list array
			strcpy (authstring_list[authstring_count].value,tempBuf);
			// Increase the midtier_count
			authstring_count = authstring_count+1;
         }

		 // DEBUG-LOGGING:   DEBUG_LOGGING
		 else if (strncmp(buffer, DEBUG_LOGGING, strlen(DEBUG_LOGGING)) == 0)
         {
            position = strlen(DEBUG_LOGGING);
            while ((buffer[position] == ' ') || (buffer[position] == '\t'))
               position++;
            if (strlen(&buffer[position]) <=
                (size_t) (AR_MAX_FULL_FILENAME - AR_MAX_FILENAME_SIZE))
               strcpy(tempBuf, &buffer[position]);
            ///else               ** name too long; ignore it...
			logInfo("DEBUG-LOGGING:");
			logInfo(tempBuf);
			//strcpy(notify_mech, tempBuf);
			debug_logging = atol(tempBuf);
         }

		 // LICENSE-MASK:  LICENSE_MASK
		 else if (strncmp(buffer, LICENSE_MASK, strlen(LICENSE_MASK)) == 0)
         {
            position = strlen(LICENSE_MASK);
            while ((buffer[position] == ' ') || (buffer[position] == '\t'))
               position++;
            if (strlen(&buffer[position]) <=
                (size_t) (AR_MAX_FULL_FILENAME - AR_MAX_FILENAME_SIZE))
               strcpy(tempBuf, &buffer[position]);
            ///else               ** name too long; ignore it...
			logInfo("LICENSE-MASK:");
			logInfo(tempBuf);
			//strcpy(license_mask, tempBuf);
			license_mask = atol(tempBuf);
         }

		 // LICENSE-TYPE:  LICENSE_TYPE
		 else if (strncmp(buffer, LICENSE_TYPE, strlen(LICENSE_TYPE)) == 0)
         {
            position = strlen(LICENSE_TYPE);
            while ((buffer[position] == ' ') || (buffer[position] == '\t'))
               position++;
            if (strlen(&buffer[position]) <=
                (size_t) (AR_MAX_FULL_FILENAME - AR_MAX_FILENAME_SIZE))
               strcpy(tempBuf, &buffer[position]);
            ///else               ** name too long; ignore it...
			logInfo("LICENSE-TYPE:");
			logInfo(tempBuf);
			//strcpy(license_type, tempBuf);
			license_type = atol(tempBuf);
         }

		 // LICENSE-FTS:  LICENSE_FTS
		 else if (strncmp(buffer, LICENSE_FTS, strlen(LICENSE_FTS)) == 0)
         {
            position = strlen(LICENSE_FTS);
            while ((buffer[position] == ' ') || (buffer[position] == '\t'))
               position++;
            if (strlen(&buffer[position]) <=
                (size_t) (AR_MAX_FULL_FILENAME - AR_MAX_FILENAME_SIZE))
               strcpy(tempBuf, &buffer[position]);
            ///else               ** name too long; ignore it...
			logInfo("LICENSE-FTS:");
			logInfo(tempBuf);
			//strcpy(license_mask, tempBuf);
			license_fts = atol(tempBuf);
         }

		 // LICENSE-APPS: LICENSE_APPS
		 else if (strncmp(buffer, LICENSE_APPS, strlen(LICENSE_APPS)) == 0)
         {
            position = strlen(LICENSE_APPS);
            while ((buffer[position] == ' ') || (buffer[position] == '\t'))
               position++;
            if (strlen(&buffer[position]) <=
                (size_t) (AR_MAX_FULL_FILENAME - AR_MAX_FILENAME_SIZE))
               strcpy(tempBuf, &buffer[position]);
            ///else               ** name too long; ignore it...
			logInfo("LICENSE-APPS:");
			logInfo(tempBuf);
			strcpy(license_apps, tempBuf);
         }

		 // GROUP-MEMBERSHIP: GROUP_MEMBERSHIP
		 else if (strncmp(buffer, GROUP_MEMBERSHIP, strlen(GROUP_MEMBERSHIP)) == 0)
         {
            position = strlen(GROUP_MEMBERSHIP);
            while ((buffer[position] == ' ') || (buffer[position] == '\t'))
               position++;
            if (strlen(&buffer[position]) <=
                (size_t) (AR_MAX_FULL_FILENAME - AR_MAX_FILENAME_SIZE))
               strcpy(tempBuf, &buffer[position]);
            ///else               ** name too long; ignore it...
			logInfo("GROUP-MEMBERSHIP:");
			logInfo(tempBuf);
			group_membership = atol(tempBuf);
         }

		 // GROUP-NAMES: GROUP_NAMES
		 else if (strncmp(buffer, GROUP_NAMES, strlen(GROUP_NAMES)) == 0)
         {
            if (group_membership==0)
            {
                logDebug("Not using static Group assignment. Groups will be assigned from the User form.");
                //group_names[255] = NULL;
                //logInfo("GROUP-NAMES:");
			    //logInfo(group_names);
            }
            else
            {
                logDebug("Using static Group assignment.");
                position = strlen(GROUP_NAMES);
                while ((buffer[position] == ' ') || (buffer[position] == '\t'))
                position++;
                if (strlen(&buffer[position]) <=
                    (size_t) (AR_MAX_FULL_FILENAME - AR_MAX_FILENAME_SIZE))
                strcpy(tempBuf, &buffer[position]);
                ///else               ** name too long; ignore it...
			    logInfo("GROUP-NAMES:");
			    logInfo(tempBuf);
			    strcpy(group_names, tempBuf);
            }
         }

		 // NOTIFY-MECH:   NOTIFY_MECH
		 else if (strncmp(buffer, NOTIFY_MECH, strlen(NOTIFY_MECH)) == 0)
         {
            position = strlen(NOTIFY_MECH);
            while ((buffer[position] == ' ') || (buffer[position] == '\t'))
               position++;
            if (strlen(&buffer[position]) <=
                (size_t) (AR_MAX_FULL_FILENAME - AR_MAX_FILENAME_SIZE))
               strcpy(tempBuf, &buffer[position]);
            ///else               ** name too long; ignore it...
			logInfo("NOTIFY-MECH:");
			logInfo(tempBuf);
			//strcpy(notify_mech, tempBuf);
			notify_mech = atol(tempBuf);
         }
	  }
   }

   // All done, close the file
   fcstatus = fclose(fp);
   if(fcstatus != 0)
   {
		logInfo("Problem closing areasso.cfg file");
   }
   if (status != NULL)
      memset(status, 0, sizeof(status));

   return AR_RETURN_OK;
}

/*****************************************************************************/
/*                                                                           */
/*                          ARPluginTermination                              */
/*                                                                           */
/*****************************************************************************/
/* Description: This function is called by the plug-in service to terminate  */
/*    the plug-in.  This is where the plug-in should deallocate any          */
/*    resources that have been allocated either globally or by each instance */
/*    created by ARPluginCreateInstance().                                   */
/*                                                                           */
/*****************************************************************************/

ARPLUGIN_EXPORT int ARPluginTermination(
ARStatusList *status        /* OUT; status of the operation */
)
{
   if (status != NULL)
      memset(status, 0, sizeof(status));

   return AR_RETURN_OK;
}

/*****************************************************************************/
/*                                                                           */
/*                          ARPluginCreateInstance                           */
/*                                                                           */
/*****************************************************************************/
/* Description: This function is called by the plug-in service to create an  */
/*    instance of the plug-in.  Each instance is guaranteed to be involved   */
/*    in one thread of operation at any one time.                            */
/*                                                                           */
/*    The structure returned via the 'object' pointer will be provided in    */
/*    subsequent plug-in calls.  This allows you to attach arbitrary data    */
/*    to an instance that will be inherently thread safe.                    */
/*                                                                           */
/*****************************************************************************/

ARPLUGIN_EXPORT int ARPluginCreateInstance(
void         **object,   /* OUT; plug-in instance */
ARStatusList  *status    /* OUT; status of the operation */
)
{
   if (status != NULL)
      memset(status, 0, sizeof(status));

   if (object != NULL)
   {
      /*
       * Set *object to point to something that you have
       * allocated and initialized.
       */
      *object = NULL;
   }

   return AR_RETURN_OK;
}

/*****************************************************************************/
/*                                                                           */
/*                          ARPluginDeleteInstance                           */
/*                                                                           */
/*****************************************************************************/
/* Description: This function is called by the plug-in service to delete an  */
/*    instance of the plug-in.  Each instance is guaranteed to be involved   */
/*    in one thread of operation at any one time.                            */
/*                                                                           */
/*****************************************************************************/

ARPLUGIN_EXPORT int ARPluginDeleteInstance(
void         *object,  /* IN;  plug-in instance to delete*/
ARStatusList *status   /* OUT; status of the operation */
)
{
   if (object != NULL)
   {
      /*
       * Anything that you allocated in ARPluginCreateInstance
       * should be deallocated here.
       */
   }

   return AR_RETURN_OK;
}

/*****************************************************************************/
/*                                                                           */
/*                          AREAVerifyLoginCallback                          */
/*                                                                           */
/*****************************************************************************/
/* Description: This function is called whenever a request is made by the AR */
/*    System Server to authenticate a user.                                  */
/*                                                                           */
/*    The user name and password (unencrypted) are passed as parameters.     */
/*                                                                           */
/*    A customized authentication plug-in must define this function.  Any    */
/*    global information or resources accessed here must be protected with   */
/*    appropriate mutual exclusion locks to be multi-thread safe.            */
/*                                                                           */
/*    A customized authentication plug-in must return a response.  A NULL    */
/*    response will be interpreted as a failed login attempt.                */
/*                                                                           */
/*****************************************************************************/

ARPLUGIN_EXPORT void AREAVerifyLoginCallback(
void                *object,         /* IN;  plug-in instance */
ARAccessNameType     user,           /* IN;  user name to authenticate */
ARAccessNameType     password,       /* IN;  user's password */
ARAccessNameType     networkAddr,    /* IN;  AR API client's IP address */
ARNameType           authString,     /* IN;  used for misc. purposes */
AREAResponseStruct **response        /* OUT; success/fail login w/ info */
)
{
   *response = (AREAResponseStruct *) malloc (sizeof(AREAResponseStruct));
   if (*response == NULL)
      return;

   passed_login=0;

   logDebug ("Username: ");
   logDebug (user);
   //logDebug ("Password: ");
   //logDebug (password);
   logDebug ("Network Address: ");
   logDebug (networkAddr);
   logDebug ("Auth String: ");
   logDebug (authString);

	/*
	This is where we check to see if the user:
	1) Is coming from one of the defined Mid-Tier IP Address(s)
	2) Has provided the correct Password String (provided by the Mid-Tier SSO Authenticator)
	3) Has provided the correct Authentication String (provided by the Mid-Tier SSO Authenticator)
	*/

	/*

	Added to support a Crystal (BOXI) Report server login requests.
		When a Mid-Tier user runs a BOXI report, only the password is passed in
		and not the authentication string. So here, we check to see only if the
		password is correct
	*/
    
	if(boxi_ip && strcmp(boxi_ip, networkAddr)==0){
		if(password && strcmp(password,PASS_STRING)==0){
			logDebug("User logging in from a matching BOXI-IP and matching password: ");
			logDebug(boxi_ip);
			passed_login=1;
		}
		else {
			logDebug("Login request came from the BOXI-IP address, but password does not match");
			passed_login=0;
		}
	}
	else {
		logDebug("Login request not coming from the BOXI-IP, checking MID-TIER-IP's...");
	}
	
	for(i=0; i <midtier_count; i++) // Loop through all midtiers from the list
	{
		if(passed_login==1)
		{
			break;
		}
		if(midtier_list[i].value && strcmp(midtier_list[i].value,networkAddr)==0) // Check for a matching Mid-Tier IP Address
		{
			if(password && strcmp(password,PASS_STRING)==0) // First lets check the password and make sure it matches
			{
				if(authstring_count>0)// Now lets check the if they are using any custom AUTH-STRING(s)
				{
					for(y=0; y<authstring_count; y++)
					{
						if(authstring_list[y].value && strcmp(authstring_list[y].value,authString)==0)
						{
							logDebug("User logging in from a matching Authentication String and Mid-Tier IP: ");
							logDebug(midtier_list[i].value);
							passed_login=1;
							break;
						}
						else
						{
							if(y==authstring_count-1) // Last AUTH-STRING
							{
								logDebug("User did not provide a valid Authentication String.");
								passed_login=0;
							}
						}
					}
				}
				else // Not using any custom AUTH-STRING(s), lets check the default one.
				{
					if(authString && strcmp(authString,AUTH_STRING_DEFAULT)==0)
					{
						logDebug("User logging in from a matching Authentication String and Mid-Tier IP: ");
						logDebug(midtier_list[i].value);
						passed_login=1;
						break;
					}
					else
					{
						logDebug("User did not provide a valid Authentication String.");
						passed_login=0;
					}
				}
			}
			else
			{
				logDebug("User did not provide a valid Password String.");
				passed_login=0;
			}
		}
		else // Did not match this Mid-Tier IP Address
		{
			if(i==midtier_count-1) // Last Mid-Tier IP Address
			{
				logDebug("User NOT logging in from Mid-Tier IP Address.");
				passed_login=0;
			}
			else // Not the last Mid-Tier IP Address, continue with the next one.
			{
				continue;
			}
		}
	}

	if(passed_login==1)
	{
		// Passed, assign the license
		(*response)->licenseMask  = license_mask;
		(*response)->licenseWrite = license_type;
		(*response)->licenseFTS   = license_fts;
		(*response)->licenseRes1  = AR_LICENSE_TYPE_NONE;
		//(*response)->licenseApps  = license_apps;
        if(group_membership==0){
            (*response)->groups       = NULL;
        }
        else{
            (*response)->groups       = group_names;
        }
		(*response)->notifyMech   = notify_mech;
		(*response)->email        = NULL;
		(*response)->loginStatus  = AREA_LOGIN_SUCCESS;
		(*response)->messageText  = NULL;
		(*response)->logText      = NULL;
		(*response)->modTime      = 0;
		logDebug ("User passed AREA SSO authentication. Login Success");

		return;
	}
	else
	{
		// Fail the login
		(*response)->loginStatus  = AREA_LOGIN_FAILED;
		(*response)->messageText  = NULL;
		(*response)->logText      = NULL;
		logDebug ("User did not pass AREA SSO authentication. Login Failed");
		return;
	}
   return;
}


/*****************************************************************************/
/*                                                                           */
/*                             AREANeedToSyncCallback                        */
/*                                                                           */
/*****************************************************************************/
/* Description: This function is called periodically at the request of the   */
/*    AR System server.                                                      */
/*                                                                           */
/*    A customized authentication plug-in must define this function.  Any    */
/*    global information or resources accessed here must be protected with   */
/*    appropriate mutual exclusion locks to be multi-thread safe.            */
/*                                                                           */
/*    A non-zero return value will instruct the AR System server to flush    */
/*    its cache of user information.                                         */
/*                                                                           */
/*****************************************************************************/

ARPLUGIN_EXPORT int AREANeedToSyncCallback(
void              *object         /* IN; plug-in instance */
)
{
   return 0;
}


/*****************************************************************************/
/*                                                                           */
/*                               AREAFreeCallback                            */
/*                                                                           */
/*****************************************************************************/
/* Description: This function is called after a response is made to the AR   */
/*    System Server to authenticate a user.                                  */
/*                                                                           */
/*    A pointer to the response structure returned by                        */
/*    AREAVerifyLoginCallback() is passed as a parameter.                    */
/*                                                                           */
/*    A customized authentication plug-in must define this function.  Any    */
/*    global information or resources accessed here must be protected with   */
/*    appropriate mutual exclusion locks to be multi-thread safe.            */
/*                                                                           */
/*    A customized authentication plug-in must return a response.  A NULL    */
/*    response will be interpreted as a failed login attempt.                */
/*                                                                           */
/*****************************************************************************/

ARPLUGIN_EXPORT void AREAFreeCallback(
void                *object,    /* IN; plug-in instance */
AREAResponseStruct  *response   /* IN; if needed, free the response */
)
{
   /* Since we allocated the response in AREAVerifyLoginCallback(), we */
   /* should free it here.                                             */

   if (response != NULL)
      free (response);

   return;
}

/*****************************************************************************/
/*                                                                           */
/*                        ARPluginSetProperties                              */
/*                                                                           */
/*****************************************************************************/
/* Description: This function is called by the plug-in service to pass along */
/*    information about various properties or facilities that the plug-in    */
/*    should be aware of.                                                    */
/*                                                                           */
/*****************************************************************************/

ARPLUGIN_EXPORT int ARPluginSetProperties(
ARPropList      *propList,  /* IN; properties from the plug-in service */
ARStatusList    *status     /* OUT; error message(s)*/
)
{

   unsigned int i;
   void *fptr;
   if (propList == NULL)
      return AR_RETURN_OK;

   for (i = 0; i < propList->numItems; i++)
   {
      switch(propList->props[i].prop)
      {
      case AR_PLUGIN_PROP_LOG_FUNCTION:
        /* Identify the pointer to the logging function for this
         * version of plug-in
         */
         if (propList->props[i].value.dataType == AR_DATA_TYPE_BYTES &&
             propList->props[i].value.u.byteListVal != NULL)
         {
            memcpy(&fptr,
                   (void*)propList->props[i].value.u.byteListVal->bytes,
                   sizeof(void *));
            logFunc = (AR_PLUGIN_LOG_FUNCTION)fptr;
         }
         break;
      default:
         break;
      }
   }
 return AR_RETURN_OK;
}

/*****************************************************************************/
/*                                                                           */
/*                  logInfo, logSevere, logDebug                             */
/*                                                                           */
/*****************************************************************************/
/* Description: Wrapper around Log Functions. Logs in plugin log             */
/*****************************************************************************/

void logInfo (char  *info)
{
   if (logFunc != NULL)
   {
      id.type = AR_PLUGIN_TYPE_AREA;
      strcpy(id.name, "AREA.SSO");
      id.version = AREA_PLUGIN_VERSION;
	       (*logFunc)(&id, AR_PLUGIN_LOG_INFO, info);
   }
}

void logSevere (char  *info)
{
   if (logFunc != NULL)
   {
      id.type = AR_PLUGIN_TYPE_AREA;
      strcpy(id.name, "AREA.SSO");
      id.version = AREA_PLUGIN_VERSION;
	       (*logFunc)(&id, AR_PLUGIN_LOG_SEVERE, info);
   }
}
void logDebug (char  *info)
{
   if (logFunc != NULL && debug_logging==1)
   {
      id.type = AR_PLUGIN_TYPE_AREA;
      strcpy(id.name, "AREA.SSO");
      id.version = AREA_PLUGIN_VERSION;
	       (*logFunc)(&id, AR_PLUGIN_LOG_INFO, info);
   }
}
